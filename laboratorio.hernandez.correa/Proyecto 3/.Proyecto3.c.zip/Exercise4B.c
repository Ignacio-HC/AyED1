#Include <stdio.h>
Int main (void)
{ 
   Int x,y,z,m ;
 printf("Ingrese un valor para x\n");
 scanf("%d", &x);
 printf("Ingrese un valor para y\n");
 scanf("%d", &y);
 printf("Ingrese un valor para z\n");
 scanf("%d", &z);
 printf("Ingrese un valor para m\n");
 scanf("%d", &m);
 printf("Estado σ0 : x=%d, y=%d, z=%d, m=%d\n", x, y, z, m);
	if (x < y) {
m = x ;
	}
else (x=>y) {
m = y;
	}
 printf( Estado σ1  : x=%d, y=%d, z=%d, m=%d\n", x, y, z, m);
if (m<z) {
skip
 	}
else (m => z){
m = z ;
	}
printf (" Estado σ2:  x=%d, y=%d, z=%d, m=%d\n", x, y, z, m);
return 0;
}

--El valor final de la variable m es 4
