1)
#include <stdio.h>
int main (void)
{ 
  int x,y,i ;
  printf ("Ingrese un valor para x\n") ;
  scanf (%d , &x);
  printf ("Ingrese un valor para y\n") ;
  scanf (%d , &y);
  printf ("Ingrese un valor para i\n") ;
  scanf (%d , &i);
  i=0;
while (x =>y) {
x = x-y ;
i = i +1;
}
printf ("Estado final: x=%d, y=%d, i = %d\n", x,y,i);
return 0;
} 

2)

#include <stdio.h><stdbool.h>
int main (void)
{ 
  int x,i, temp;
  bool res;
  printf ("Ingrese un valor para x\n") ;
  scanf (%d , &x);
  printf ("Ingrese un valor para i\n") ;
  scanf (%d , &i);
  printf ("Ingrese un valor para res\n") ;
  scanf (%d , &temp);
 i=2;
res = True;
while (i <= x && res)
 {
res = res && ( (x mod i) !0 );
i = i +1;
 }
printf ("Estado final: x=%d, i=%d, res = %d\n", x,i,res);
return 0;
}

