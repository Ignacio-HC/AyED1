H)

#include <stdio,h>
int main (void)
{ 
    int i ; 
    printf ("Ingrese un valor para i\n");
    scanf ("%d", &i);
    while (i !=0)
    {
    i = i-1;
    } 
    printf ("Estado final: %d\n", i);
       return 0;
}

I)
#include <stdio,h>
int main (void)
{ 
    int i ; 
    printf ("Ingrese un valor para i\n");
    scanf ("%d", &i);
    while (i !=0)
    {
    i = 0;
    } 
    printf ("Estado final: %d\n", i);
       return 0;
}
