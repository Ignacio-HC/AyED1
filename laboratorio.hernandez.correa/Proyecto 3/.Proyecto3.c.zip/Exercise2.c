#include <stdio.h>
int main(void)
{
    int x=4,y=-4,z=8, b=1, w=1;
    printf("x %% 4 == 0 = %d\n", x % 4 == 0);
    printf("x + y == 0 && y - x == (-1) * z = %d\n", x + y == 0 && y - x == (-1) * z);
    printf("not b && gcc -Wall -Wextra -g -std=c99 Exercise1.c -o Exercise1gcc -Wall -Wextra -g -std=c99 Exercise1.c -o Exercise1gcc -Wall -Wextra -g -std=c99 Exercise1.c -o Exercise1gcc -Wall -Wextra -g -std=c99 Exercise1.c -o Exercise1w = %d\n", !(b && w));
    return 0;
}