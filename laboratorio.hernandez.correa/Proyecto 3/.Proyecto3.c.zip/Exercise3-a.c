
#include <stdio.h>
int main(void)
{
    int x;
    printf("Ingrese el valor de x\n");
    scanf("%d",&x);
    printf("Estado inicial : %d\n", x);
    x=5;
    printf("Estado final : %d\n", x);
    return 0;
}