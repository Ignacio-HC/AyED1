

#include <stdio.h>
int perdirEntero (void)
{  int x;
printf ("Ingrese un numero x");
scanf ("%d", &x);
return x;
}

void imprimeEntero (int x)
{ prinf ("%d\n",x);
}